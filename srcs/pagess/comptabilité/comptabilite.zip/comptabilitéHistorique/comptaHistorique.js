import React from 'react'



export default function ComptaHistorique() {
    return(
        <h1>Historique</h1>
    )
}