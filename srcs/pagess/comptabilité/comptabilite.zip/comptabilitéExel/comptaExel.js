import React from 'react'



export default function ComptaExel() {
    return(
        <h1>exel</h1>
    )
}