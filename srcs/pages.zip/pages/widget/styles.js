import { makeStyles } from "@material-ui/styles";

export default makeStyles(theme => ({
  paper: {
    margin: theme.spacing(4),
    backgroundColor: "#f3f3f3"
  },
}));
