import { makeStyles } from '@material-ui/styles';

export default makeStyles(theme => (
  {
    expansion: {
      backgroundColor: theme.palette.primary.light,
      color: 'white '
    }
  }
))