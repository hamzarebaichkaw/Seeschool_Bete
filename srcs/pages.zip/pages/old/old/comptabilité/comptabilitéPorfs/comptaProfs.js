import React from 'react'



export default function ComptaProfs() {
    return(
        <h1>Profs</h1>
    )
}